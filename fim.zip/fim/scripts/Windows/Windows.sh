#!/bin/sh

sensor_type=Windows
rootdir=/opt/fim
sensors_dir=$rootdir/sensors
logs=$rootdir/logs
curdate=$(date +%Y%m%d%H%M%S)
errors=$rootdir/errors
windir=$rootdir/windows_shared/$1

#Check if sensor disabled

if [ ! -f "$sensors_dir/$1/disabled" ];
then

#First File Creation

if [ ! -f "$sensors_dir/$1/last-entry" ];
then
    if [[ -f $windir/filesystem.txt && -f $windir/server_registry.txt ]];
	then
	cat $windir/filesystem.txt | grep -v "drw" | grep -v "lrw" | grep -v "Windows/Microsoft.NET/Framework" | grep -v "Windows/SoftwareDistribution/DataStore/Logs/" | grep -v "Windows/SoftwareDistribution/EventCache" | grep -v "Windows/SoftwareDistribution/SelfUpdate" | grep -v "System32/LogFiles" | grep -v "System32/drivers/symefasi/data/" | grep -v "System32/winevt/Logs" | grep -v ".log" | grep -v ".log." | grep -v ".LOG" | grep -v "System32/7B296FB0" | grep -v "System32/spool/spooler.xml" | grep -v "System32/spool/SpoolerETW.etl" | grep -v "security/database/edb.chk" | grep -v "security/database/tmp.edb" | grep -v "System32/eCCf_" | grep -v "System32/wbem/Repository" | grep -v "security/templates/policies/gpt" | grep -v "security/database/secedit.sdb" | grep -v "System32/pgp-" > $sensors_dir/$1/last-entry
	cat $windir/server_registry.txt > $sensors_dir/$1/last-entry-registry
	rm $windir/filesystem.txt
	rm $windir/server_registry.txt
	else
	exit 1;
    fi;

else

#Second File Creation

if [[ -f $windir/filesystem.txt && -f $windir/server_registry.txt ]];
then
cat $windir/filesystem.txt | grep -v "drw" | grep -v "lrw" | grep -v "Windows/Microsoft.NET/Framework" | grep -v "Windows/SoftwareDistribution/DataStore/Logs/" | grep -v "Windows/SoftwareDistribution/EventCache" | grep -v "Windows/SoftwareDistribution/SelfUpdate" | grep -v "System32/LogFiles" | grep -v "System32/drivers/symefasi/data/" | grep -v "System32/winevt/Logs" | grep -v ".log" | grep -v ".log." | grep -v ".LOG" | grep -v "System32/7B296FB0" | grep -v "System32/spool/spooler.xml" | grep -v "System32/spool/SpoolerETW.etl" | grep -v "security/database/edb.chk" | grep -v "security/database/tmp.edb" | grep -v "System32/eCCf_" | grep -v "System32/wbem/Repository" | grep -v "security/templates/policies/gpt" | grep -v "security/database/secedit.sdb" | grep -v "System32/pgp-" > /dev/shm/$1.check
cat $windir/server_registry.txt > /dev/shm/$1.reg.check

#Making Diff

    #File Diffs
    if diff -q "$sensors_dir/$1/last-entry" "/dev/shm/$1.check" > /dev/null;
    then
    mv /dev/shm/$1.check $sensors_dir/$1/last-entry
    rm $windir/filesystem.txt
    else

	#Mail Headers

	echo "From: fim@mail.com" >> $sensors_dir/$1/hist/diff.$curdate
	echo "To: admin@mail.com" >> $sensors_dir/$1/hist/diff.$curdate
	echo "Subject: Sensor $1 ($2) change detected" >> $sensors_dir/$1/hist/diff.$curdate
	date >> $sensors_dir/$1/hist/diff.$curdate
	echo "Sensor $1 ($2) change detected:" >> $sensors_dir/$1/hist/diff.$curdate

	#Diff

	diff "$sensors_dir/$1/last-entry" "/dev/shm/$1.check" >> $sensors_dir/$1/hist/diff.$curdate

	#Local Logging

	echo "---------------------" >> $logs/$1.alerts.log
	cat $sensors_dir/$1/hist/diff.$curdate >> $logs/$1.alerts.log
	echo "---------------------" >> $logs/$1.alerts.log

	#Send Mail

	cat $sensors_dir/$1/hist/diff.$curdate | sendmail -t

	#Syslog

	logger -p local1.info -t $1 "FIM Configuration Changed"

	yes | cp /dev/shm/$1.check $sensors_dir/$1/hist/state.$curdate
	mv /dev/shm/$1.check $sensors_dir/$1/last-entry
	rm $windir/filesystem.txt

    fi

    #Registry Diffs
    if diff -q "$sensors_dir/$1/last-entry-registry" "/dev/shm/$1.reg.check" > /dev/null;
    then
    mv /dev/shm/$1.reg.check $sensors_dir/$1/last-entry-registry
    rm $windir/server_registry.txt
    else

	#Mail Headers

	echo "From: fim@mail.com" >> $sensors_dir/$1/hist/diff_reg.$curdate
	echo "To: admin@mail.com" >> $sensors_dir/$1/hist/diff_reg.$curdate
	echo "Subject: Sensor $1 ($2) registry change detected" >> $sensors_dir/$1/hist/diff_reg.$curdate
	date >> $sensors_dir/$1/hist/diff_reg.$curdate
	echo "Sensor $1 ($2) registry change detected:" >> $sensors_dir/$1/hist/diff_reg.$curdate

	#Diff

	$rootdir/scripts/$sensor_type/Registry.sh $1 | uniq >> $sensors_dir/$1/hist/diff_reg.$curdate

	#Local Logging

	echo "---------------------" >> $logs/$1.alerts.log
	cat $sensors_dir/$1/hist/diff_reg.$curdate >> $logs/$1.alerts.log
	echo "---------------------" >> $logs/$1.alerts.log

	#Send Mail

	cat $sensors_dir/$1/hist/diff_reg.$curdate | sendmail -t

	#Syslog

	logger -p local1.info -t $1 "FIM Configuration Changed"

	yes | cp /dev/shm/$1.reg.check $sensors_dir/$1/hist/state_reg.$curdate
	mv /dev/shm/$1.reg.check $sensors_dir/$1/last-entry-registry
	rm $windir/server_registry.txt

    fi

else
exit 1;
fi


fi

else
exit 1;
fi;