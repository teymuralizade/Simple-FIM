#!/bin/bash

sensor_type=Windows
rootdir=/opt/fim
sensors_dir=$rootdir/sensors
logs=$rootdir/logs
curdate=$(date +%Y%m%d%H%M%S)
errors=$rootdir/errors
windir=$rootdir/windows_shared/$1

tac /dev/shm/$1.reg.check > /dev/shm/$1.inverted.reg.check
tac $sensors_dir/$1/last-entry-registry > /dev/shm/$1.last-entry-registry.reg.check

diff "/dev/shm/$1.last-entry-registry.reg.check" "/dev/shm/$1.inverted.reg.check"

diff_newline_number=$(diff --unchanged-line-format="" --old-line-format="" --new-line-format="%dn " /dev/shm/$1.last-entry-registry.reg.check /dev/shm/$1.inverted.reg.check)
diff_newline_number_temp=$(echo $diff_newline_number)
for strings1 in $diff_newline_number_temp;
do
tail -n +$strings1 /dev/shm/$1.inverted.reg.check | grep -m 1 "HKEY_LOCAL"
done;

diff_oldline_number=$(diff --unchanged-line-format="" --old-line-format="%dn " --new-line-format="" /dev/shm/$1.last-entry-registry.reg.check /dev/shm/$1.inverted.reg.check)
diff_oldline_number_temp=$(echo $diff_oldline_number)
for strings2 in $diff_oldline_number_temp;
do
tail -n +$strings2 /dev/shm/$1.inverted.reg.check | grep -m 1 "HKEY_LOCAL"
done;

rm /dev/shm/$1.inverted.reg.check
rm /dev/shm/$1.last-entry-registry.reg.check