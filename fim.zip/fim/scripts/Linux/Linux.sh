#!/bin/sh

sensor_type=Linux
rootdir=/opt/fim
sensors_dir=$rootdir/sensors
logs=$rootdir/logs
curdate=$(date +%Y%m%d%H%M%S)
conn_status=/dev/shm/$1.status
errors=$rootdir/errors

#Check if sensor disabled

if [ ! -f "$sensors_dir/$1/disabled" ];
then

#First File Creation

if [ ! -f "$sensors_dir/$1/last-entry" ];
then
	$rootdir/scripts/$sensor_type/$sensor_type.first_check $1 $2 $3
	if grep "$1 Connection OK" "$conn_status";
	then
	cat /dev/shm/$1.first_check | grep -v "tree -" | grep -v "exit" | grep -v "Connection to $2 closed by remote host" > /dev/shm/$1.first_check_tmp
	cat /dev/shm/$1.first_check_tmp > /dev/shm/$1.first_check
	rm /dev/shm/$1.first_check_tmp
	mv /dev/shm/$1.first_check $sensors_dir/$1/last-entry
	rm $conn_status
	else
	rm /dev/shm/$1.first_check
	rm $conn_status

	#Report About Connection Problem via Mail

	#echo "From: ossec@azericard.com" >> $errors/$1.error.$curdate
	#echo "To: tsupport@azericard.com" >> $errors/$1.error.$curdate
	#echo "Subject: Sensor $1 ($2) change detected" >> $errors/$1.error.$curdate
	#date >> $errors/$1.error.$curdate
	#echo "Sensor $1 ($2) Connection Problem!!!" >> $errors/$1.error.$curdate
	#cat $errors/$1.error.$curdate | sendmail -t

	#Local Logging

	#echo "---------------------" >> $logs/$1.alerts.log
	#cat $errors/$1.error.$curdate >> $logs/$1.alerts.log
	#echo "---------------------" >> $logs/$1.alerts.log

	#Report via Syslog

	logger -p local1.info -t $1 "Connection Problem"

	fi

else

#Second File Creation

$rootdir/scripts/$sensor_type/$sensor_type.check $1 $2 $3
if grep "$1 Connection OK" "$conn_status";
then
rm $conn_status
cat /dev/shm/$1.check | grep -v "tree -" | grep -v "exit" | grep -v "Connection to $2 closed by remote host" > /dev/shm/$1.check_tmp
cat /dev/shm/$1.check_tmp > /dev/shm/$1.check
rm /dev/shm/$1.check_tmp
#Making Diff

    if diff -q "$sensors_dir/$1/last-entry" "/dev/shm/$1.check" > /dev/null;
    then
    mv /dev/shm/$1.check $sensors_dir/$1/last-entry
    else

	#Mail Headers

	echo "From: ossec@azericard.com" >> $sensors_dir/$1/hist/diff.$curdate
	echo "To: tsupport@azericard.com" >> $sensors_dir/$1/hist/diff.$curdate
	echo "Subject: Sensor $1 ($2) change detected" >> $sensors_dir/$1/hist/diff.$curdate
	date >> $sensors_dir/$1/hist/diff.$curdate
	echo "Sensor $1 ($2) change detected:" >> $sensors_dir/$1/hist/diff.$curdate

	#Diff

	diff "$sensors_dir/$1/last-entry" "/dev/shm/$1.check" >> $sensors_dir/$1/hist/diff.$curdate
	#exclude_diff=$(awk 'NR==7' $sensors_dir/$1/hist/diff.$curdate)

	#Local Logging

	echo "---------------------" >> $logs/$1.alerts.log
	cat $sensors_dir/$1/hist/diff.$curdate >> $logs/$1.alerts.log
	echo "---------------------" >> $logs/$1.alerts.log

	#Send Mail
	#if [[ $exclude_diff == *"Connection to $2 closed by remote host."* ]] || [[ $exclude_diff == *"exit"* ]]; then
	#rm $sensors_dir/$1/hist/diff.$curdate
	#mv /dev/shm/$1.check $sensors_dir/$1/last-entry
	#else

	cat $sensors_dir/$1/hist/diff.$curdate | sendmail -t

	#Syslog

	logger -p local1.info -t $1 "FIM Configuration Changed"

	yes | cp /dev/shm/$1.check $sensors_dir/$1/hist/state.$curdate
	mv /dev/shm/$1.check $sensors_dir/$1/last-entry
	#fi
    fi
else
rm /dev/shm/$1.check
rm $conn_status

#Report About Connection Problem via Mail
#echo "From: ossec@azericard.com" >> $errors/$1.error.$curdate
#echo "To: tsupport@azericard.com" >> $errors/$1.error.$curdate
#echo "Subject: Sensor $1 ($2) change detected" >> $errors/$1.error.$curdate
#date >> $errors/$1.error.$curdate
#echo "Sensor $1 ($2) Connection Problem!!!" >> $errors/$1.error.$curdate
#cat $errors/$1.error.$curdate | sendmail -t

#Local Logging
#echo "---------------------" >> $logs/$1.alerts.log
#cat $errors/$1.error.$curdate >> $logs/$1.alerts.log
#echo "---------------------" >> $logs/$1.alerts.log
#Report via Syslog
logger -p local1.info -t $1 "Connection Problem"
fi


fi

else
exit 1;
fi;