#!/bin/sh

rootdir=/opt/fim
logs=$rootdir/logs
alive_logs=$logs/alive

echo "From: fim@mail.com" >> $alive_logs/alive.mail
echo "To: admin@mail.com" >> $alive_logs/alive.mail
echo "Subject: FIM Alive Test Message" >> $alive_logs/alive.mail
date >> $alive_logs/alive.mail
echo "FIM Alive Test Message" >> $alive_logs/alive.mail
cat $alive_logs/alive.mail | sendmail -t

echo "---------------------" >> $alive_logs/alive.log
cat $alive_logs/alive.mail >> $alive_logs/alive.log
echo "---------------------" >> $alive_logs/alive.log

rm $alive_logs/alive.mail